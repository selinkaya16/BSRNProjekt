# legende


# check input on correct syntax
import string

# loop for the shooting
def get_shot(guesses):
    while True:
        try:
            shot = int(input("Pls enter your guess."))
            if shot < 0 or shot > 99:
                print("Incorrect entry. Pls try again.")
            elif shot in guesses:
                print("Used before. Pls try again.")
            else:
                break
        except:
            print("Incorrect entry. Pls enter your guess.")  # falls kein int
    return shot


# create a 10x10 grid
def show_board(hit, miss, comp):
    print("Battleship")
    print("     0  1  2  3  4  5  6  7  8  9")
    place = 0
    for x in range(10):
        row = ""
        for y in range(10):
            ch = " _ "
            if place in hit:
                ch = " o "
            elif place in miss:
                ch = " x "
            elif place in comp:
                ch = " 0 "
            row = row + ch
            place = place + 1
        print(x, " ", row)


# check shoot on hit or miss or comp
def check_shot(shoot, boat1, boat2, hit, miss, comp):
    if shoot in boat1:
        # hit.append(shoot)# wenn das dasteht, dann nicht deutlich, ob schiff versenkt oder nicht
        # bzw user sieht es nicht der computer erkennt es schon
        boat1.remove(shoot)
        if len(boat1) > 0:
            hit.append(shoot)
        else:
            comp.append(shoot)
    elif shoot in boat2:
        boat2.remove(shoot)
        if len(boat2) > 0:
            hit.append(shoot)
        else:
            comp.append(shoot)
    else:
        miss.append(shoot)

    return boat1, boat2, hit, miss, comp


class Player():
    """Docstring: Class representing players."""

    def __init__(self, name):
        """Docstring: Initialises the players."""
        self.name = name
        self.hit = []
        self.miss = []
        self.comp = []
        self.guesses = self.hit + self.miss + self.comp  # Lst, in der alle  Schüsse stehen-> alles geraten

# where players place their boats
boat1 = [45, 46, 47]
boat2 = [6, 16, 26]

while True:
    anfangen = input("If you want to start the game 'Battleship', please enter '1': ")
    if anfangen != "1":
        print("das spiel soll nicht beginnen")
        break
    # Beschreibung des spiels, legende mittels print-funktion
    else:  # einleitung

        while True:
            gegenspieler = input("Would you like to play against another player, please enter '1' : ")
            if gegenspieler == "1":  # gegen Menschen
                spieler1 = input("Player 1 please enter your name: ")
                if spieler1 != "":
                    player_one = Player(spieler1)
                else:
                    player_one = Player("Player 1")  # falls kein Name eingegeben wird

                spieler2 = input("Player 2 please enter your name: ")
                if spieler2 != "":
                    player_two = Player(spieler2)
                else:
                    player_two = Player("Player 2")

            else:
                print("Incorrect entry")


            print("Player 1 may start.")
            # ab hier beginnt das spiel
            counter = 0
            # ungerade dann ist spieler 2 dran sonst spieler 1
            print("")
            while True:

                if counter % 2 == 0:  # falls gerade spieler 1 dran
                    print(player_one.name, "it's your turn")
                    shot = get_shot(player_one.guesses)
                    boat1, boat2, player_one.hit, player_one.miss, player_one.comp = check_shot(shot, boat1, boat2,
                                                                                                player_one.hit,
                                                                                                player_one.miss,
                                                                                                player_one.comp)
                    show_board(player_one.hit, player_one.miss, player_one.comp)
                elif counter % 2 == 1:  # falls ungerade spieler 2 dran
                    print(player_two.name, "it's your turn")
                    shot = get_shot(player_two.guesses)
                    boat1, boat2, player_two.hit, player_two.miss, player_two.comp = check_shot(shot, boat1, boat2,
                                                                                                player_two.hit,
                                                                                                player_two.miss,
                                                                                                player_two.comp)
                    show_board(player_two.hit, player_two.miss, player_two.comp)
                counter += 1
                print("")

                # the player whose boats hits 0 first will lose
                if len(boat1) < 1:
                    print(player_two.name, "You won")
                    break
                elif len(boat2) < 1:
                    print(player_one.name, "You won")
                    break
            print("this game is finished")